import { useNavigate } from 'react-router-dom'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { describeError } from '../../lib/error-copy.js'
import { ROUTES } from '../../lib/routes.js'
import { useSolver } from '../../state/solver-context.jsx'
import { PdfDownloadButton } from './PdfDownloadButton.jsx'
// ⚠ Lo implementa Daniel. Acordado con él: recibe `result` (el sobre completo del backend) y pinta
// clasificación, solución/parámetros/contradicción, forma reducida y comprobación SIN recalcular.
import { ResultContent } from './ResultContent.jsx'

/** Etapa 4 · Resultado. Aquí solo viven los estados (carga, vacío, error), el PDF y las acciones. */
export default function ResultPage() {
  const { state, reset, retry } = useSolver()
  const navigate = useNavigate()

  if (state.status === 'loading') {
    return (
      <p role="status" className="mx-auto max-w-4xl text-muted-foreground">
        Resolviendo el sistema…
      </p>
    )
  }

  // Sin resultado (por ejemplo, entró directo a /resultado): hay que volver a capturar.
  if (!state.result) {
    const error = state.status === 'error' && state.error ? describeError(state.error) : null
    return (
      <div className="mx-auto flex max-w-4xl flex-col items-start gap-4">
        <h1 className="text-2xl font-semibold tracking-tight">Todavía no hay un resultado</h1>
        <p className="text-muted-foreground">Captura un sistema y resuélvelo para ver la solución aquí.</p>
        {error && (
          <Alert variant="destructive">
            <AlertTitle>{error.title}</AlertTitle>
            <AlertDescription className="flex flex-col items-start gap-2">
              <span>{error.detail}</span>
              {error.canRetry && <Button size="sm" onClick={retry}>Reintentar</Button>}
            </AlertDescription>
          </Alert>
        )}
        <Button onClick={() => navigate(state.size ? ROUTES.data : ROUTES.size)}>Ir a capturar datos</Button>
      </div>
    )
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-8">
      <ResultContent result={state.result} />
      <PdfDownloadButton />
      <footer className="flex flex-wrap justify-between gap-2">
        <Button variant="outline" onClick={() => navigate(ROUTES.procedure)}>Volver al procedimiento</Button>
        <Button
          onClick={() => {
            reset()
            navigate(ROUTES.size)
          }}
        >
          Resolver otro sistema
        </Button>
      </footer>
    </div>
  )
}

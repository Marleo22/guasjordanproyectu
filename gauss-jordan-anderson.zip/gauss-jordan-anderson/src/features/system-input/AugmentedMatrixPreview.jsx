/** Vista en vivo de la matriz aumentada [A | b] con lo que se va escribiendo. Solo lectura. */
export function AugmentedMatrixPreview({ size, matrix }) {
  return (
    <figure className="flex flex-col gap-2">
      <figcaption className="text-sm font-medium">Matriz aumentada [A | b]</figcaption>
      <div className="overflow-x-auto">
        <table className="border-separate border-spacing-0 font-mono text-sm" aria-label="Matriz aumentada">
          <tbody>
            {matrix.map((row, i) => (
              <tr key={i}>
                {row.map((value, j) => {
                  const text = String(value).trim()
                  return (
                    <td
                      key={j}
                      className={`min-w-14 px-3 py-1.5 text-center ${j === size ? 'border-l-2 border-foreground/60' : ''} ${text ? '' : 'text-muted-foreground'}`}
                    >
                      {text || '—'}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </figure>
  )
}

import { useMemo, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { describeError } from '../../lib/error-copy.js'
import { ROUTES } from '../../lib/routes.js'
import { SAMPLES } from '../../lib/sample-matrices.js'
import { isMatrixEmpty } from '../../state/solver.reducer.js'
import { useSolver } from '../../state/solver-context.jsx'
import { AugmentedMatrixPreview } from './AugmentedMatrixPreview.jsx'
import { EquationGrid } from './EquationGrid.jsx'

/** Etapa 2 · Datos. Captura, envía a la API y navega a Procedimiento si todo sale bien. */
export default function DataPage() {
  const { state, setCell, loadSample, clear, solve, dismissError } = useSolver()
  const navigate = useNavigate()
  const [sampleId, setSampleId] = useState('')

  const samples = useMemo(() => SAMPLES.filter((s) => s.size === state.size), [state.size])

  // Sin tamaño elegido no hay nada que capturar: de vuelta a la etapa 1.
  if (!state.size) return <Navigate to={ROUTES.size} replace />

  const loading = state.status === 'loading'
  const empty = isMatrixEmpty(state.matrix)
  const selected = samples.find((s) => s.id === sampleId) ?? samples[0]
  const error = state.status === 'error' && state.error ? describeError(state.error) : null

  async function onSolve() {
    // Si ya hay resultado y nada cambió, no se vuelve a pedir: se sigue al procedimiento.
    if (state.result) return navigate(ROUTES.procedure)
    if (await solve()) navigate(ROUTES.procedure)
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight">
          Datos del sistema {state.size} × {state.size}
        </h1>
        <p className="text-muted-foreground">
          Escribe enteros, decimales o fracciones como 1/3. Deja en 0 la variable que no aparece en una ecuación.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        {samples.length > 1 && (
          <select
            aria-label="Ejemplo a cargar"
            value={selected?.id ?? ''}
            onChange={(e) => setSampleId(e.target.value)}
            disabled={loading}
            className="h-9 rounded-md border border-input bg-background px-2 text-sm"
          >
            {samples.map((s) => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
        )}
        <Button type="button" variant="outline" disabled={loading || !selected} onClick={() => loadSample(selected)}>
          Cargar ejemplo
        </Button>
        <Button type="button" variant="ghost" disabled={loading || empty} onClick={clear}>
          Limpiar
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>{error.title}</AlertTitle>
          <AlertDescription className="flex flex-col items-start gap-2">
            <span>{error.detail}</span>
            {state.formErrors.map((m) => <span key={m}>{m}</span>)}
            <span className="flex gap-2">
              {error.canRetry && <Button size="sm" onClick={onSolve}>Reintentar</Button>}
              <Button size="sm" variant="ghost" onClick={dismissError}>Cerrar</Button>
            </span>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-8 md:grid-cols-[minmax(0,1fr)_auto] md:items-start">
        <EquationGrid
          size={state.size}
          matrix={state.matrix}
          cellErrors={state.cellErrors}
          disabled={loading}
          onChange={setCell}
        />
        <AugmentedMatrixPreview size={state.size} matrix={state.matrix} />
      </div>

      {empty && !loading && (
        <p className="text-sm text-muted-foreground">
          La matriz está vacía. Escribe los coeficientes o carga un ejemplo para poder resolver.
        </p>
      )}

      <footer className="flex justify-between gap-2">
        <Button type="button" variant="outline" disabled={loading} onClick={() => navigate(ROUTES.size)}>
          Cambiar tamaño
        </Button>
        <Button type="button" disabled={loading || empty} aria-busy={loading} onClick={onSolve}>
          {loading ? 'Resolviendo…' : state.result ? 'Ver procedimiento' : 'Resolver'}
        </Button>
      </footer>
    </div>
  )
}

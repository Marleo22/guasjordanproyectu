// Ejecutar: node --test   (sin dependencias; usa el runner nativo de Node)
import test from 'node:test'
import assert from 'node:assert/strict'
import { ACTIONS as A, initialState, solverReducer as reduce } from './solver.reducer.js'

const run = (...actions) => actions.reduce((s, a) => reduce(s, a), initialState)
const RESULT = { classification: 'unique', steps: [{}, {}, {}] }

test('elegir tamaño crea matriz vacía de n × (n+1)', () => {
  const s = run({ type: A.SET_SIZE, size: 3 })
  assert.equal(s.matrix.length, 3)
  assert.ok(s.matrix.every((r) => r.length === 4 && r.every((c) => c === '')))
})

test('volver a elegir el mismo tamaño conserva lo capturado', () => {
  const s = run({ type: A.SET_SIZE, size: 2 }, { type: A.SET_CELL, row: 0, col: 0, value: '5' }, { type: A.SET_SIZE, size: 2 })
  assert.equal(s.matrix[0][0], '5')
})

test('cambiar de tamaño reinicia matriz y resultado', () => {
  const s = run(
    { type: A.SET_SIZE, size: 2 },
    { type: A.SOLVE_SUCCESS, result: RESULT, submitted: {} },
    { type: A.SET_SIZE, size: 4 },
  )
  assert.equal(s.matrix.length, 4)
  assert.equal(s.result, null)
  assert.equal(s.status, 'idle')
})

test('editar una celda invalida el resultado anterior', () => {
  const s = run(
    { type: A.SET_SIZE, size: 2 },
    { type: A.SOLVE_SUCCESS, result: RESULT, submitted: { size: 2 } },
    { type: A.SET_CELL, row: 1, col: 1, value: '9' },
  )
  assert.equal(s.result, null)
  assert.equal(s.submitted, null)
  assert.equal(s.status, 'idle')
  assert.equal(s.matrix[1][1], '9')
})

test('el 422 se mapea a errores por celda (índices base 0) y editar la celda limpia su error', () => {
  const err = {
    kind: 'validation',
    message: 'Falta el coeficiente de b en la ecuación 2',
    fields: { 'matrix.1.1': ['Falta el coeficiente de b en la ecuación 2'], size: ['Tamaño inválido'] },
  }
  let s = run({ type: A.SET_SIZE, size: 2 }, { type: A.SOLVE_ERROR, error: err })
  assert.equal(s.status, 'error')
  assert.equal(s.cellErrors['1-1'], 'Falta el coeficiente de b en la ecuación 2')
  assert.deepEqual(s.formErrors, ['Tamaño inválido'])
  s = reduce(s, { type: A.SET_CELL, row: 1, col: 1, value: '3' })
  assert.equal(s.cellErrors['1-1'], undefined)
})

test('un error de servidor no genera errores por celda y conserva la matriz', () => {
  const s = run(
    { type: A.SET_SIZE, size: 2 },
    { type: A.SET_CELL, row: 0, col: 0, value: '1' },
    { type: A.SOLVE_ERROR, error: { kind: 'server', message: 'x', requestId: 'abc' } },
  )
  assert.deepEqual(s.cellErrors, {})
  assert.equal(s.error.requestId, 'abc')
  assert.equal(s.matrix[0][0], '1')
})

test('fallo del PDF conserva el resultado en pantalla', () => {
  const s = run(
    { type: A.SET_SIZE, size: 2 },
    { type: A.SOLVE_SUCCESS, result: RESULT, submitted: { size: 2 } },
    { type: A.PDF_START },
    { type: A.PDF_ERROR, error: { kind: 'network', message: 'sin red' } },
  )
  assert.equal(s.pdf.status, 'error')
  assert.equal(s.result, RESULT)
})

test('el índice de paso se limita al rango de steps', () => {
  let s = run({ type: A.SET_SIZE, size: 2 }, { type: A.SOLVE_SUCCESS, result: RESULT, submitted: {} })
  s = reduce(s, { type: A.SET_STEP_INDEX, index: 99 })
  assert.equal(s.stepIndex, 2)
  s = reduce(s, { type: A.SET_STEP_INDEX, index: -4 })
  assert.equal(s.stepIndex, 0)
})

test('limpiar vacía la matriz pero conserva el tamaño; reset vuelve al inicio', () => {
  let s = run({ type: A.SET_SIZE, size: 3 }, { type: A.SET_CELL, row: 0, col: 0, value: '7' }, { type: A.CLEAR })
  assert.equal(s.size, 3)
  assert.equal(s.matrix[0][0], '')
  s = reduce(s, { type: A.RESET })
  assert.equal(s, initialState)
})

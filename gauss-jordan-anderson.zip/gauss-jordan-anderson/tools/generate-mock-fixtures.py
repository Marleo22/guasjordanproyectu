#!/usr/bin/env python3
"""
Genera src/lib/sample-matrices.js y src/lib/mock-fixtures.js.

IMPORTANTE: esto NO es el solver del proyecto. El solver real es
GaussJordanService (Laravel, Diego). Este script solo fabrica respuestas de
ejemplo con la forma del contrato para que el frontend se desarrolle con el
mock mientras la API no existe. Cuando /solve funcione, compara su salida con
estos fixtures (MAT-01..MAT-06) y reemplaza el mock.

Uso:  python tools/generate-mock-fixtures.py
"""
import json
from fractions import Fraction
from pathlib import Path

VARS = "abcde"
PARAMS = "tsuvw"
OUT = Path(__file__).resolve().parent.parent / "src" / "lib"


def fmt(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def fmt_coef(x: Fraction) -> str:
    return fmt(x) if x.denominator == 1 else f"({fmt(x)})"


def snap(m):
    return [[fmt(c) for c in row] for row in m]


def row_formula(kind, r, i=None, f=None):
    if kind == "swap":
        return f"F{r + 1} ↔ F{i + 1}"
    if kind == "scale":
        return f"F{r + 1} ← {fmt_coef(f)}·F{r + 1}"
    sign = "−" if f > 0 else "+"
    mag = abs(f)
    k = "" if mag == 1 else f"{fmt_coef(mag)}·"
    return f"F{i + 1} ← F{i + 1} {sign} {k}F{r + 1}"


def expr(const: Fraction, terms):
    """terms: lista de (coef, nombre_parametro). Devuelve '1 - t', '2/3', 't'..."""
    parts = []
    if const != 0 or not terms:
        parts.append(fmt(const))
    for coef, name in terms:
        if coef == 0:
            continue
        mag = abs(coef)
        body = name if mag == 1 else (f"{fmt(mag)}{name}" if mag.denominator == 1 else f"({fmt(mag)}){name}")
        if not parts:
            parts.append(("-" if coef < 0 else "") + body)
        else:
            parts.append(("- " if coef < 0 else "+ ") + body)
    return " ".join(parts)


def solve(matrix):
    n = len(matrix)
    m = [[Fraction(c) for c in row] for row in matrix]
    initial = snap(m)
    steps = []

    def record(kind, label, rows, before):
        steps.append({
            "index": len(steps) + 1,
            "type": kind,
            "operation": label,
            "modified_rows": [x + 1 for x in rows],
            "before": before,
            "after": snap(m),
        })

    r = 0
    for c in range(n + 1):  # la última columna (b) detecta contradicciones
        if r >= n:
            break
        p = next((i for i in range(r, n) if m[i][c] != 0), None)
        if p is None:
            continue
        if p != r:
            before = snap(m)
            m[r], m[p] = m[p], m[r]
            record("swap", row_formula("swap", r, p), [r, p], before)
        if m[r][c] != 1:
            before = snap(m)
            f = Fraction(1) / m[r][c]
            m[r] = [v * f for v in m[r]]
            record("scale", row_formula("scale", r, f=f), [r], before)
        if c == n:  # pivote en b => 0 = k, no se elimina hacia arriba
            r += 1
            break
        for i in range(n):
            if i != r and m[i][c] != 0:
                before = snap(m)
                f = m[i][c]
                m[i] = [a - f * b for a, b in zip(m[i], m[r])]
                record("eliminate", row_formula("eliminate", r, i, f), [i], before)
        r += 1

    rref = snap(m)
    base = {"initial_matrix": initial, "steps": steps, "rref": rref}

    # ¿contradicción? fila 0 0 ... 0 | k
    for i in range(n):
        if all(v == 0 for v in m[i][:n]) and m[i][n] != 0:
            lhs = " + ".join(f"0{VARS[j]}" for j in range(n))
            return {
                "classification": "inconsistent",
                "solution": None,
                "free_variables": [],
                "parameters": {},
                "contradiction": {"row": i + 1, "left": "0", "right": fmt(m[i][n]),
                                  "equation": f"{lhs} = {fmt(m[i][n])}"},
                "verification": [],
                **base,
            }

    pivots = {}
    for i in range(n):
        for j in range(n):
            if m[i][j] != 0:
                pivots[j] = i
                break
    free = [j for j in range(n) if j not in pivots]

    if free:
        pname = {j: PARAMS[k] for k, j in enumerate(free)}
        params = {}
        for j in range(n):
            if j in pname:
                params[VARS[j]] = pname[j]
            else:
                row = m[pivots[j]]
                params[VARS[j]] = expr(row[n], [(-row[k], pname[k]) for k in free])
        return {
            "classification": "infinite",
            "solution": None,
            "free_variables": [VARS[j] for j in free],
            "parameters": params,
            "contradiction": None,
            "verification": [],
            **base,
        }

    sol = {VARS[j]: m[pivots[j]][n] for j in range(n)}
    orig = [[Fraction(c) for c in row] for row in matrix]
    verification = []
    for i in range(n):
        left = sum(orig[i][j] * sol[VARS[j]] for j in range(n))
        verification.append({"equation": i + 1, "left": fmt(left), "right": fmt(orig[i][n]),
                             "ok": left == orig[i][n]})
    return {
        "classification": "unique",
        "solution": {k: fmt(v) for k, v in sol.items()},
        "free_variables": [],
        "parameters": {},
        "contradiction": None,
        "verification": verification,
        **base,
    }


def with_b(A, x):
    return [[str(c) for c in row] + [fmt(sum(Fraction(c) * Fraction(v) for c, v in zip(row, x)))]
            for row in A]


SAMPLES = [
    # id, etiqueta, matriz aumentada (strings)
    ("MAT-01", "2×2 · solución única", [["2", "1", "5"], ["1", "-1", "1"]]),
    ("MAT-05", "2×2 · pivote inicial cero", [["0", "1", "2"], ["1", "1", "3"]]),
    ("MAT-06", "2×2 · con fracciones", [["1/2", "1", "1"], ["1", "-1", "0"]]),
    ("MAT-02", "3×3 · solución única (ejemplo Figma)",
     [["1", "1", "1", "6"], ["2", "3", "1", "11"], ["1", "2", "3", "14"]]),
    ("MAT-03", "3×3 · infinitas soluciones",
     [["1", "1", "1", "2"], ["2", "2", "2", "4"], ["1", "-1", "1", "0"]]),
    ("MAT-04", "3×3 · sin solución",
     [["1", "1", "0", "3"], ["2", "2", "0", "6"], ["1", "1", "0", "4"]]),
    ("EX-4x4", "4×4 · solución única",
     with_b([[0, 2, 1, 1], [1, 1, 1, 1], [2, 1, -1, 1], [1, -1, 2, 0]], [1, 2, 3, 4])),
    ("EX-5x5", "5×5 · solución única con fracciones",
     with_b([[2, 1, 0, 0, 1], [1, 3, 1, 0, 0], [0, 1, 4, 1, 0], [0, 0, 1, 5, 1], [1, 0, 0, 1, 6]],
            [1, 2, 3, 4, 5])),
]

# Comprobaciones contra los valores esperados del plan (sección Pruebas)
expected = {
    "MAT-01": ("unique", {"a": "2", "b": "1"}),
    "MAT-02": ("unique", {"a": "1", "b": "2", "c": "3"}),
    "MAT-05": ("unique", {"a": "1", "b": "2"}),
    "MAT-06": ("unique", {"a": "2/3", "b": "2/3"}),
}

fixtures = []
sample_js = []
for sid, label, matrix in SAMPLES:
    res = solve(matrix)
    size = len(matrix)
    if sid in expected:
        cls, sol = expected[sid]
        assert res["classification"] == cls and res["solution"] == sol, (sid, res["solution"])
    if sid == "MAT-03":
        assert res["free_variables"] == ["c"] and res["parameters"] == {"a": "1 - t", "b": "1", "c": "t"}
        assert res["rref"] == [["1", "0", "1", "1"], ["0", "1", "0", "1"], ["0", "0", "0", "0"]]
    if sid == "MAT-04":
        assert res["contradiction"]["row"] == 2 and res["contradiction"]["right"] == "1"
        assert res["rref"] == [["1", "1", "0", "3"], ["0", "0", "0", "1"], ["0", "0", "0", "0"]]
    if sid.startswith("EX-"):
        assert res["classification"] == "unique", sid
        assert all(v["ok"] for v in res["verification"])
    sample_js.append({"id": sid, "label": label, "size": size, "matrix": matrix})
    fixtures.append({"id": sid, "size": size, "matrix": matrix, "response": res})

HEADER = "// GENERADO por tools/generate-mock-fixtures.py — no editar a mano.\n"

(OUT / "sample-matrices.js").write_text(
    HEADER
    + "// Matrices de ejemplo para el botón «Cargar ejemplo» (coinciden con los casos MAT-xx del plan).\n"
    + "export const SAMPLES = "
    + json.dumps(sample_js, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
(OUT / "mock-fixtures.js").write_text(
    HEADER
    + "// Respuestas con la forma del contrato JSON. Solo las usa el mock (VITE_USE_MOCK=true).\n"
    + "export const FIXTURES = "
    + json.dumps(fixtures, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
print(f"OK: {len(fixtures)} fixtures generados en {OUT}")
for f in fixtures:
    r = f["response"]
    print(f'  {f["id"]:7} {r["classification"]:12} pasos={len(r["steps"])}')
